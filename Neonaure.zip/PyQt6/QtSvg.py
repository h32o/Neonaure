"""PyQt6.QtSvg compatibility shim → PySide6.QtSvg"""

from PySide6.QtSvg import *  # noqa: F401,F403

import PySide6.QtSvg as _orig
_globals = globals()
_names = [n for n in dir(_orig) if not n.startswith("_")]
for _n in _names:
    _globals[_n] = getattr(_orig, _n)
del _orig, _globals, _names, _n