"""PyQt6.QtCore compatibility shim → PySide6.QtCore"""

from PySide6.QtCore import *  # noqa: F401,F403

import PySide6.QtCore as _orig
_globals = globals()
_names = [n for n in dir(_orig) if not n.startswith("_")]
for _n in _names:
    _globals[_n] = getattr(_orig, _n)

# PyQt6 name aliases that PySide6 spells differently
pyqtSignal = _orig.Signal
pyqtSlot = _orig.Slot
pyqtProperty = _orig.Property

_globals["pyqtSignal"] = pyqtSignal
_globals["pyqtSlot"] = pyqtSlot
_globals["pyqtProperty"] = pyqtProperty

del _orig, _globals, _names, _n, pyqtSignal, pyqtSlot, pyqtProperty