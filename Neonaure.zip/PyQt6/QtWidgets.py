"""PyQt6.QtWidgets compatibility shim → PySide6.QtWidgets"""

from PySide6.QtWidgets import *  # noqa: F401,F403

# Make sure the star-import symbols are visible to ``dir()`` and re-export
import PySide6.QtWidgets as _orig
_globals = globals()
_names = [n for n in dir(_orig) if not n.startswith("_")]
for _n in _names:
    _globals[_n] = getattr(_orig, _n)
del _orig, _globals, _names, _n