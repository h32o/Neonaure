"""
PyQt6 compatibility shim — re-exports PySide6.

Drop this folder (named ``pyqt6``) onto your project root or
sys.path and existing ``from PyQt6 import …`` statements will
use PySide6 under the hood.

Only the most commonly-used sub-modules are shimmed here.
If you need additional ones, just copy the pattern — it is a
one-liner per module.
"""

# Version info that mimics PyQt6
__version__ = "6.8.1"

# ---------------------------------------------------------------------------
# Sub-module shims  (lazy imports so we only pull in what is actually used)
# ---------------------------------------------------------------------------
import importlib
import sys


def __getattr__(name: str):
    """Lazy-import any PySide6 sub-module as if it were a PyQt6 one."""
    _MAP = {
        "QtCore": "PySide6.QtCore",
        "QtGui": "PySide6.QtGui",
        "QtWidgets": "PySide6.QtWidgets",
        "QtNetwork": "PySide6.QtNetwork",
        "QtMultimedia": "PySide6.QtMultimedia",
        "QtOpenGL": "PySide6.QtOpenGL",
        "QtOpenGLWidgets": "PySide6.QtOpenGLWidgets",
        "QtPrintSupport": "PySide6.QtPrintSupport",
        "QtSvg": "PySide6.QtSvg",
        "QtSvgWidgets": "PySide6.QtSvgWidgets",
        "QtTest": "PySide6.QtTest",
        "QtWebEngineCore": "PySide6.QtWebEngineCore",
        "QtWebEngineWidgets": "PySide6.QtWebEngineWidgets",
        "uic": "pyqt6.uic",
    }
    real_name = _MAP.get(name)
    if real_name is None:
        raise AttributeError(f"module 'pyqt6' has no attribute {name!r}")
    mod = importlib.import_module(real_name)
    sys.modules[f"pyqt6.{name}"] = mod  # cache for future lookups
    return mod