"""PyQt6.QtSvgWidgets compatibility shim → PySide6.QtSvgWidgets"""

from PySide6.QtSvgWidgets import *  # noqa: F401,F403

import PySide6.QtSvgWidgets as _orig
_globals = globals()
_names = [n for n in dir(_orig) if not n.startswith("_")]
for _n in _names:
    _globals[_n] = getattr(_orig, _n)
del _orig, _globals, _names, _n