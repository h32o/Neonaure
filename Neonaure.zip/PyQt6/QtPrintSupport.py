"""PyQt6.QtPrintSupport compatibility shim → PySide6.QtPrintSupport"""

from PySide6.QtPrintSupport import *  # noqa: F401,F403

import PySide6.QtPrintSupport as _orig
_globals = globals()
_names = [n for n in dir(_orig) if not n.startswith("_")]
for _n in _names:
    _globals[_n] = getattr(_orig, _n)
del _orig, _globals, _names, _n