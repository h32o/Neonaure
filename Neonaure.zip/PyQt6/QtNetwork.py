"""PyQt6.QtNetwork compatibility shim → PySide6.QtNetwork"""

from PySide6.QtNetwork import *  # noqa: F401,F403

import PySide6.QtNetwork as _orig
_globals = globals()
_names = [n for n in dir(_orig) if not n.startswith("_")]
for _n in _names:
    _globals[_n] = getattr(_orig, _n)
del _orig, _globals, _names, _n