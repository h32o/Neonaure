"""PyQt6.QtWebEngineCore compatibility shim → PySide6.QtWebEngineCore"""

from PySide6.QtWebEngineCore import *  # noqa: F401,F403

import PySide6.QtWebEngineCore as _orig
_globals = globals()
_names = [n for n in dir(_orig) if not n.startswith("_")]
for _n in _names:
    _globals[_n] = getattr(_orig, _n)
del _orig, _globals, _names, _n