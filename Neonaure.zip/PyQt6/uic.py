"""PyQt6.uic compatibility shim → PySide6.QtUiTools + loadUi helper.

PyQt6 provides ``pyqt6.uic.loadUi('file.ui')`` which returns a widget.
PySide6 does not ship a direct equivalent; we wrap QUiLoader to match
the call signature as closely as possible.
"""

import sys
from pathlib import Path

from PySide6.QtCore import QObject
from PySide6.QtUiTools import QUiLoader
from PySide6.QtWidgets import QWidget


# ---------------------------------------------------------------------------
# Minimal ``loadUi`` that mimics PyQt6's pyqt6.uic.loadUi
# ---------------------------------------------------------------------------

def loadUi(uifile, baseinstance=None, package=None, resource_suffix="_rc", **kwargs):
    """Load a ``.ui`` file and (optionally) populate *baseinstance*.

    Parameters
    ----------
    uifile : str or Path
        Path to the ``.ui`` file produced by Qt Designer.
    baseinstance : QWidget, optional
        If given, the loaded UI is applied *onto* this existing widget
        (same behaviour as PyQt6).
    package : ignored
        Accepted for API compatibility; not used.
    resource_suffix : str
        Suffix appended to the base name when looking for a compiled
        resource module (e.g. ``foo_rc``).  Not used by this shim but
        kept for signature compatibility.

    Returns
    -------
    QWidget
        The loaded widget.  When *baseinstance* is provided it is the
        same object that was passed in.
    """
    loader = QUiLoader()

    # If the caller gave us an existing widget, we need to make sure
    # QUiLoader doesn't create a brand-new top-level widget but instead
    # populates the one we already have.
    if baseinstance is not None:
        # QUiLoader.createWidget needs a parent; pass baseinstance so
        # child widgets are parented correctly.
        ui_widget = loader.load(str(uifile), baseinstance)
        if ui_widget is not None and ui_widget is not baseinstance:
            # Reparent all children of the loaded widget into baseinstance
            child = ui_widget.takeChild()
            while child is not None:
                baseinstance.layout().addWidget(child) if baseinstance.layout() else child.setParent(baseinstance)
                child = ui_widget.takeChild()
            # Copy properties / layout if feasible
            if ui_widget.layout() is not None:
                # Transfer the layout
                new_layout = ui_widget.layout()
                # Walk items and re-parent
                while new_layout.count():
                    item = new_layout.takeAt(0)
                    w = item.widget()
                    if w is not None:
                        w.setParent(baseinstance)
        return baseinstance

    widget = loader.load(str(uifile))
    return widget


# Re-export for star-imports
__all__ = ["loadUi", "QUiLoader"]